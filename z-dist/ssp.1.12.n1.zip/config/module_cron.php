<?php
/* 
 * Configuration for the Cron module.
 * 
 * $Id: $
 */

$config = array (
	'key' => 'changeme',
	'allowed_tags' => array('daily', 'hourly', 'frequent'),
	'debug_message' => TRUE,
	'sendemail' => FALSE,

);