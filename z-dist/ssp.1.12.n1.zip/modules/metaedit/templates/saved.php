<?php



$this->includeAtTemplateBase('includes/header.php');


echo('<h1>Metadata successfully saved</h1>');

echo('<p><a href="index.php">Go back to metadata registry listing</a></p>');



$this->includeAtTemplateBase('includes/footer.php');

