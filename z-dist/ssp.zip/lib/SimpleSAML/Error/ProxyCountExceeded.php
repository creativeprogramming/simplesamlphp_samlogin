<?php


class SimpleSAML_Error_ProxyCountExceeded extends SimpleSAML_Error_Exception {

}

?>