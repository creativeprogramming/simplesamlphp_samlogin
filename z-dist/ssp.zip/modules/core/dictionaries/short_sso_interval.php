<?php

$lang = array(
	'warning' => array (
		'en' => 'We have detected that there is only a few seconds since you last authenticated with this service provider, and therefore assume that there is a problem with this SP.',
	),
	'warning_header' => array (
		'en' => 'To short interval between single sign on events.',
	),
	'retry' => array (
		'en' => 'Retry login',
	),

);


?>