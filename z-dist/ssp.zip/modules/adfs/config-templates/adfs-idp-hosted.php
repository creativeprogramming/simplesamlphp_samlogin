<?php

$config = array(

	'key' =>  'server.pem',
	'cert' => 'server.crt',
	'auth' => 'auth/login.php',

);

?>
