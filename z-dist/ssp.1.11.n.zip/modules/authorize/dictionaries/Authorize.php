<?php

$lang = array(
	'403_header' => array (
		'en' => 'Access forbidden',
		'es' => 'Acceso denegado',
	),
	'403_text' => array (
		'en' => "You don't have the needed privileges to access this application. Please contact the administrator if you find this to be incorrect.",
		'es' => "No tiene los privilegios necesarios para acceder a esta aplicación. Si considera que esto no es correcto, consulte el administrador.",
	),
);


?>
