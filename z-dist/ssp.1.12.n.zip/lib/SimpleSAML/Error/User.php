<?php

/**
 * Baseclass for user error exceptions
 * 
 * 
 * @author Thomas Graff <thomas.graff@uninett.no>
 * @package simpleSAMLphp_base
 * @version $Id$
 *
 */
class SimpleSAML_Error_User extends SimpleSAML_Error_Exception{
	
}

?>