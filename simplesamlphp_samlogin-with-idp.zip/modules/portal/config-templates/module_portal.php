<?php
/* 
 * Configuration for the module portal.
 * 
 * $Id: $
 */

$config = array (

	'pagesets' => array(
		array('frontpage_welcome', 'frontpage_config', 'frontpage_auth', 'frontpage_federation'),
		array('santitycheck', 'statistics'),
	),
	
);

?>
