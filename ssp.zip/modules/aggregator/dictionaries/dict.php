<?php

$lang = array(
	'frontpage_link' => array (
		'en' => 'Metadata aggregator',
	),
	'aggregator_header' => array (
		'en' => 'Aggregators',
	),
	'no_aggregators' => array (
		'en' => 'No aggregators defined in configuration.',
	),
	'text' => array (
		'en' => 'text',
	),
);


?>